INSERT INTO "Settings" (id, "quickRead", trending, swipe, breaking, "darkMode", "podcastMode", "smartNotifications", "followTopics", "readingModes", "breakingTimeline", "focusMode", "audioMode", "updatedAt")
VALUES (
  'settings-default', true, true, true, true, true, true, true, true, true, true, true, true, NOW()
)
ON CONFLICT (id) DO NOTHING;

INSERT INTO "Article" (id, title, content, summary, "imageUrl", category, "isTop", "isBreaking", views, "readingTime", "createdAt", "updatedAt") VALUES
('art_ai_1', 'AI chips reshape mobile robotics', 'AI hardware is moving from server-centric acceleration toward edge-native deployment, changing robotics design, power constraints, and cost models for consumer and industrial devices.', 'AI hardware is moving to the edge and changing robotics economics.', NULL, 'ai', true, true, 1900, 4, NOW() - INTERVAL '1 hour', NOW()),
('art_ai_2', 'Generative tools enter newsroom workflows', 'Editorial teams are increasingly using AI-assisted summarization, translation, and draft expansion to improve publishing speed while keeping humans in control.', 'Newsrooms are using AI to speed up editorial workflows.', NULL, 'ai', true, false, 1400, 3, NOW() - INTERVAL '2 hours', NOW()),
('art_ai_3', 'Model routing reduces inference cost', 'Provider-agnostic orchestration lets platforms choose the right model for each task, balancing cost, latency, and quality instead of hardwiring one vendor everywhere.', 'Routing across models improves cost and flexibility.', NULL, 'ai', false, false, 900, 5, NOW() - INTERVAL '5 hours', NOW()),
('art_cars_1', 'EV range improves with smarter thermal systems', 'Automakers are investing in battery thermal intelligence, software calibration, and lighter materials to improve range consistency in mixed climates.', 'Thermal systems and software are helping EVs go farther more reliably.', NULL, 'cars', true, false, 1700, 4, NOW() - INTERVAL '3 hours', NOW()),
('art_cars_2', 'ADAS stacks become more software-defined', 'Modern vehicles are consolidating perception, planning, and driver-assist features into upgradeable software layers, reducing fragmentation across models.', 'ADAS is becoming more centralized and software-defined.', NULL, 'cars', false, false, 1100, 4, NOW() - INTERVAL '6 hours', NOW()),
('art_cars_3', 'Luxury interiors now compete on screens and sound', 'Premium car makers are turning cabins into digital experience zones, blending infotainment, ambient controls, and spatial audio into a new battleground.', 'Cabin tech is becoming a key luxury differentiator.', NULL, 'cars', false, false, 800, 3, NOW() - INTERVAL '8 hours', NOW())
ON CONFLICT (id) DO NOTHING;
