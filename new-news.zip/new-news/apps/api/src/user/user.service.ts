import { Injectable } from '@nestjs/common';

const store: Record<string, { userId: string; topics: string[] }> = {};

@Injectable()
export class UserService {
  followTopic(userId: string, topic: string) {
    const current = store[userId] || { userId, topics: [] };
    current.topics = Array.from(new Set([...current.topics, topic]));
    store[userId] = current;
    return current;
  }

  getPreferences(userId: string) {
    return store[userId] || { userId, topics: [] };
  }
}
