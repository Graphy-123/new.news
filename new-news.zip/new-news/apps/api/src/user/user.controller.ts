import { Body, Controller, Get, Post, Query } from '@nestjs/common';
import { UserService } from './user.service';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post('follow-topic')
  followTopic(@Body() body: { userId: string; topic: string }) {
    return this.userService.followTopic(body.userId, body.topic);
  }

  @Get('preferences')
  getPreferences(@Query('userId') userId: string) {
    return this.userService.getPreferences(userId);
  }
}
