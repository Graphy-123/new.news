import { Injectable } from '@nestjs/common';

const articles = [
  { id: '1', title: 'AI chips reshape mobility', content: 'Long article body for AI chips and smart mobility systems.', summary: 'AI chips are changing mobility.', category: 'ai', isTop: true, isBreaking: false, views: 420, readingTime: 4, createdAt: new Date().toISOString() },
  { id: '2', title: 'Electric SUVs push new range records', content: 'Long article body for EV range and car innovation.', summary: 'EV range is improving fast.', category: 'cars', isTop: true, isBreaking: true, views: 910, readingTime: 5, createdAt: new Date().toISOString() },
  { id: '3', title: 'Foundation models enter automotive tooling', content: 'Article body about generative AI inside manufacturing.', summary: 'Generative AI enters factories.', category: 'ai', isTop: false, isBreaking: false, views: 700, readingTime: 3, createdAt: new Date().toISOString() }
];

@Injectable()
export class ArticleService {
  getArticles(category?: 'ai' | 'cars') {
    return category ? articles.filter((a) => a.category === category) : articles;
  }

  getTopArticles() {
    return articles.filter((a) => a.isTop);
  }

  getTrendingArticles() {
    return [...articles].sort((a, b) => b.views - a.views);
  }
}
