import { Controller, Get, Query } from '@nestjs/common';
import { ArticleService } from './article.service';

@Controller('articles')
export class ArticleController {
  constructor(private readonly articleService: ArticleService) {}

  @Get()
  getArticles(@Query('category') category?: 'ai' | 'cars') {
    return this.articleService.getArticles(category);
  }

  @Get('top')
  getTopArticles() {
    return this.articleService.getTopArticles();
  }

  @Get('trending')
  getTrendingArticles() {
    return this.articleService.getTrendingArticles();
  }
}
