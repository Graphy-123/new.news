import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class NotificationService {
  constructor(private readonly prisma: PrismaService) {}

  async getLatestBreakingArticle() {
    return this.prisma.article.findFirst({
      where: { isBreaking: true },
      orderBy: { createdAt: 'desc' },
    });
  }
}
