import { Controller, Get } from '@nestjs/common';

@Controller('notifications')
export class NotificationController {
  @Get('breaking')
  getBreaking() {
    return { id: '2', title: 'Electric SUVs push new range records' };
  }
}
