import { Module } from '@nestjs/common';
import { ArticleModule } from './article/article.module';
import { AiModule } from './ai/ai.module';
import { UserModule } from './user/user.module';
import { SettingsModule } from './settings/settings.module';
import { NotificationModule } from './notification/notification.module';

@Module({
  imports: [ArticleModule, AiModule, UserModule, SettingsModule, NotificationModule],
})
export class AppModule {}
