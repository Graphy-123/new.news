import { Injectable } from '@nestjs/common';
import { BrowserTTSProvider } from './providers/browser-tts.provider';

@Injectable()
export class TtsService {
  private readonly provider = new BrowserTTSProvider();

  generateAudio(text: string) {
    return this.provider.generateAudio(text);
  }
}
