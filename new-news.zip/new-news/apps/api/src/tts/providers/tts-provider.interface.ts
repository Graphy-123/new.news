export interface TTSProvider {
  generateAudio(text: string): Promise<{ url?: string; text: string }>;
}
