import { TTSProvider } from './tts-provider.interface';

export class BrowserTTSProvider implements TTSProvider {
  async generateAudio(text: string): Promise<{ text: string }> {
    return { text };
  }
}
