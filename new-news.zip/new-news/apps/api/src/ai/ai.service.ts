import { Injectable } from '@nestjs/common';

@Injectable()
export class AiService {
  summarize(text: string) {
    return text.slice(0, 140) + '...';
  }

  rewrite(text: string) {
    return `Rewritten: ${text}`;
  }

  translate(text: string, language: string) {
    return `[${language}] ${text}`;
  }
}
