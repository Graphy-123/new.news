import { AIProvider } from './ai-provider.interface';

export class MockAIProvider implements AIProvider {
  async summarize(text: string): Promise<string> {
    return text.slice(0, 220) + (text.length > 220 ? '...' : '');
  }

  async rewrite(text: string): Promise<string> {
    return `Rewritten: ${text}`;
  }

  async translate(text: string, language: string): Promise<string> {
    return `[${language}] ${text}`;
  }
}
