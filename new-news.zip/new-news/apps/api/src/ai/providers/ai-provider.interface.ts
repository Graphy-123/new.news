export interface AIProvider {
  summarize(text: string): Promise<string>;
  rewrite(text: string): Promise<string>;
  translate(text: string, language: string): Promise<string>;
}
