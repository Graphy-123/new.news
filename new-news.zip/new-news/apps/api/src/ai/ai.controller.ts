import { Body, Controller, Post } from '@nestjs/common';
import { AiService } from './ai.service';

@Controller('ai')
export class AiController {
  constructor(private readonly aiService: AiService) {}

  @Post('summarize')
  summarize(@Body() body: { text: string }) {
    return { result: this.aiService.summarize(body.text) };
  }

  @Post('rewrite')
  rewrite(@Body() body: { text: string }) {
    return { result: this.aiService.rewrite(body.text) };
  }

  @Post('translate')
  translate(@Body() body: { text: string; language: string }) {
    return { result: this.aiService.translate(body.text, body.language) };
  }
}
