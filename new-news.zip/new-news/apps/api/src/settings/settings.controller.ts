import { Controller, Get } from '@nestjs/common';

@Controller('settings')
export class SettingsController {
  @Get()
  getSettings() {
    return {
      quickRead: true,
      trending: true,
      swipe: true,
      breaking: true,
      darkMode: true,
      podcastMode: true,
      smartNotifications: true,
      followTopics: true,
      readingModes: true,
      breakingTimeline: true,
      focusMode: true,
      audioMode: true,
    };
  }
}
