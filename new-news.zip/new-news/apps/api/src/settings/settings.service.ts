import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class SettingsService {
  constructor(private readonly prisma: PrismaService) {}

  async getSettings() {
    const existing = await this.prisma.settings.findFirst();
    if (existing) return existing;

    return this.prisma.settings.create({
      data: {
        quickRead: true,
        trending: true,
        swipe: true,
        breaking: true,
        darkMode: true,
        podcastMode: true,
        smartNotifications: true,
        followTopics: true,
        readingModes: true,
        breakingTimeline: true,
        focusMode: true,
        audioMode: true,
      },
    });
  }
}
