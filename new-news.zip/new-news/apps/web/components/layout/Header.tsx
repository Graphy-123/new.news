'use client';

import { useUIStore } from '@/store/ui-store';

export function Header({ settings }: any) {
  const { toggleDarkMode, toggleFocusMode, readingMode, setReadingMode } = useUIStore();

  return (
    <header className="sticky top-0 z-50 border-b bg-white/90 backdrop-blur dark:bg-slate-950/90">
      <div className="flex items-center justify-between px-4 py-3">
        <div>
          <h1 className="text-xl font-bold">New.News</h1>
          <p className="text-xs text-slate-500">AI-powered news, app-style experience</p>
        </div>

        <div className="flex items-center gap-2">
          {settings?.readingModes && (
            <select
              value={readingMode}
              onChange={(e) => setReadingMode(e.target.value as 'day' | 'night' | 'audio')}
              className="rounded-lg border px-2 py-1 text-sm"
            >
              <option value="day">Day</option>
              <option value="night">Night</option>
              <option value="audio">Audio</option>
            </select>
          )}

          {settings?.focusMode && (
            <button onClick={toggleFocusMode} className="rounded-lg border px-3 py-1 text-sm">
              Focus
            </button>
          )}

          {settings?.darkMode && (
            <button onClick={toggleDarkMode} className="rounded-lg border px-3 py-1 text-sm">
              🌙
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
