'use client';

import { useEffect, useState } from 'react';
import { fetcher } from '@/lib/api';

export function BreakingBanner() {
  const [article, setArticle] = useState<any>(null);

  useEffect(() => {
    fetcher('/notifications/breaking').then(setArticle).catch(() => null);
  }, []);

  if (!article) return null;

  return (
    <div className="mx-4 mt-3 rounded-2xl border border-red-400 bg-red-50 p-3 dark:bg-red-950/20">
      <p className="text-sm font-semibold">🚨 Breaking News</p>
      <p className="mt-1 text-sm">{article.title}</p>
    </div>
  );
}
