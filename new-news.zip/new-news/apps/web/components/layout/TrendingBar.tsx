export function TrendingBar({ articles }: { articles: any[] }) {
  return (
    <div className="overflow-x-auto whitespace-nowrap border-b px-4 py-2 text-sm">
      <span className="mr-3 font-semibold">🔥 Trending:</span>
      {articles.map((article) => (
        <span key={article.id} className="mr-4 inline-block">
          {article.title}
        </span>
      ))}
    </div>
  );
}
