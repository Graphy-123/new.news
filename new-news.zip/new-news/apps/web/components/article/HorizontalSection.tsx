import { ArticleCard } from './ArticleCard';

export function HorizontalSection({ title, articles, settings }: any) {
  return (
    <section className="px-4 py-4">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-xl font-bold">{title} Articles</h2>
      </div>
      <div className="flex snap-x snap-mandatory gap-4 overflow-x-auto pb-2">
        {articles.map((article: any) => (
          <div key={article.id} className="min-w-[85%] snap-start sm:min-w-[340px]">
            <ArticleCard article={article} settings={settings} />
          </div>
        ))}
      </div>
    </section>
  );
}
