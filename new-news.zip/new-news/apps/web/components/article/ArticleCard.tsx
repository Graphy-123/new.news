'use client';

import { useState } from 'react';
import { postJson } from '@/lib/api';
import { useSpeech } from '@/hooks/useSpeech';

export function ArticleCard({ article, settings }: any) {
  const [showSummary, setShowSummary] = useState(false);
  const [summary, setSummary] = useState(article.summary || '');
  const { speak, stop, speaking } = useSpeech();

  const handleQuickRead = async () => {
    if (summary) {
      setShowSummary((v) => !v);
      return;
    }

    const res = await postJson<{ result: string }>('/ai/summarize', {
      text: article.content,
    });

    setSummary(res.result);
    setShowSummary(true);
  };

  return (
    <article className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900">
      <div className="flex items-start justify-between gap-3">
        <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium uppercase dark:bg-slate-800">
          {article.category}
        </span>
        <span className="text-xs text-slate-500">{article.readingTime} min read</span>
      </div>

      <h3 className="mt-3 text-lg font-semibold leading-snug">{article.title}</h3>

      <p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-300">
        {showSummary ? summary : `${article.content.slice(0, 220)}...`}
      </p>

      <div className="mt-4 flex flex-wrap gap-2">
        {settings?.quickRead && (
          <button onClick={handleQuickRead} className="rounded-xl border px-3 py-2 text-sm">
            ⚡ Quick Read
          </button>
        )}
        {settings?.audioMode && !speaking && (
          <button onClick={() => speak(showSummary ? summary : article.content)} className="rounded-xl border px-3 py-2 text-sm">
            🔊 Play
          </button>
        )}
        {settings?.audioMode && speaking && (
          <button onClick={stop} className="rounded-xl border px-3 py-2 text-sm">
            Stop
          </button>
        )}
      </div>
    </article>
  );
}
