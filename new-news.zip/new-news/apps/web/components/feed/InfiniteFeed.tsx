'use client';

import { useEffect, useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { fetcher } from '@/lib/api';
import { ArticleCard } from '@/components/article/ArticleCard';

export function InfiniteFeed({ settings }: { settings: any }) {
  const [items, setItems] = useState<any[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const { ref, inView } = useInView();

  const load = async () => {
    if (loading) return;
    setLoading(true);
    const path = `/articles?limit=10${cursor ? `&cursor=${cursor}` : ''}`;
    const data = await fetcher<any[]>(path);
    setItems((prev) => [...prev, ...data]);
    setCursor(data.length ? data[data.length - 1].id : null);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    if (inView && cursor) load();
  }, [inView]);

  return (
    <section className="px-4 py-6">
      <h2 className="mb-4 text-2xl font-bold">Latest Feed</h2>
      <div className="space-y-4">
        {items.map((article) => (
          <ArticleCard key={article.id} article={article} settings={settings} />
        ))}
      </div>
      <div ref={ref} className="h-10" />
      {loading && <p className="pt-3 text-sm text-slate-500">Loading more...</p>}
    </section>
  );
}
