import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'New.News',
  description: 'Modern AI-powered news platform',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
