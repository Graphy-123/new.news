async function getJson(path: string) {
  const base = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';
  const res = await fetch(`${base}${path}`, { cache: 'no-store' });
  return res.json();
}

export default async function HomePage() {
  const [settings, top, cars, ai, trending] = await Promise.all([
    getJson('/settings'),
    getJson('/articles/top'),
    getJson('/articles?category=cars'),
    getJson('/articles?category=ai'),
    getJson('/articles/trending'),
  ]);

  return (
    <main style={{ fontFamily: 'sans-serif', padding: 16, maxWidth: 900, margin: '0 auto' }}>
      <header style={{ position: 'sticky', top: 0, background: '#fff', padding: '12px 0', borderBottom: '1px solid #eee' }}>
        <h1>New.News</h1>
        {settings.trending && <div><strong>🔥 Trending:</strong> {trending.map((a: any) => a.title).join(' • ')}</div>}
      </header>

      <section>
        <h2>Top News</h2>
        {top.map((a: any) => <article key={a.id} style={{ border: '1px solid #ddd', borderRadius: 12, padding: 12, marginBottom: 12 }}><h3>{a.title}</h3><p>{a.summary}</p></article>)}
      </section>

      <section>
        <h2>Cars Articles</h2>
        <div style={{ display: 'flex', gap: 12, overflowX: 'auto' }}>
          {cars.map((a: any) => <article key={a.id} style={{ minWidth: 280, border: '1px solid #ddd', borderRadius: 12, padding: 12 }}><h3>{a.title}</h3><p>{a.summary}</p></article>)}
        </div>
      </section>

      <section>
        <h2>AI Articles</h2>
        <div style={{ display: 'flex', gap: 12, overflowX: 'auto' }}>
          {ai.map((a: any) => <article key={a.id} style={{ minWidth: 280, border: '1px solid #ddd', borderRadius: 12, padding: 12 }}><h3>{a.title}</h3><p>{a.summary}</p></article>)}
        </div>
      </section>
    </main>
  );
}
