import { create } from 'zustand';

type ReadingMode = 'day' | 'night' | 'audio';

interface UIState {
  darkMode: boolean;
  focusMode: boolean;
  podcastMode: boolean;
  readingMode: ReadingMode;
  toggleDarkMode: () => void;
  toggleFocusMode: () => void;
  setPodcastMode: (value: boolean) => void;
  setReadingMode: (mode: ReadingMode) => void;
}

export const useUIStore = create<UIState>((set) => ({
  darkMode: false,
  focusMode: false,
  podcastMode: false,
  readingMode: 'day',
  toggleDarkMode: () => set((s) => ({ darkMode: !s.darkMode })),
  toggleFocusMode: () => set((s) => ({ focusMode: !s.focusMode })),
  setPodcastMode: (value) => set({ podcastMode: value }),
  setReadingMode: (mode) => set({ readingMode: mode }),
}));
