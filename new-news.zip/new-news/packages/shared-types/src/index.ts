export type Category = 'ai' | 'cars';

export interface Article {
  id: string;
  title: string;
  content: string;
  summary?: string;
  imageUrl?: string;
  category: Category;
  isTop: boolean;
  isBreaking?: boolean;
  views: number;
  readingTime: number;
  createdAt: string;
}

export interface UserPreferences {
  userId: string;
  topics: Category[];
  savedArticles?: string[];
}

export interface FeatureSettings {
  quickRead: boolean;
  trending: boolean;
  swipe: boolean;
  breaking: boolean;
  darkMode: boolean;
  podcastMode: boolean;
  smartNotifications: boolean;
  followTopics: boolean;
  readingModes: boolean;
  breakingTimeline: boolean;
  focusMode: boolean;
  audioMode: boolean;
}
